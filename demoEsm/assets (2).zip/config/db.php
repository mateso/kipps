<?php

return [
    'class' => 'yii\db\Connection',
    'dsn' => 'mysql:host=localhost;dbname=kipp',
    'username' => 'root',
    'password' => 'Michael',
    'charset' => 'utf8',
];

