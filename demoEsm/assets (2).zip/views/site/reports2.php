<?php $this->params['reports_page'] = true;  ?> 

 <iframe src="http://192.168.43.30:90/Default.aspx" width="1200" height="550" frameBorder="0"></iframe>