<?php
use yii\helpers\Html;
$this->title = 'Initiate Financial Year 2016/17 ';
$this->params['breadcrumbs'][] = $this->title

?>

<div class="panel panel-default">
    <div class="panel-heading">Initiate Academic 2016/17; </div>
  <div class="panel-body">
<div class="financial-years-create">

    <h1><?= Html::encode($this->title) ?></h1>

 <div class="financial-years-form">

    <button class="btn btn-primary" type="button">
   <span class="glyphicon glyphicon-tasks"></span> Initiate Financial Year
</button>
  </div>

</div>
  </div>
</div>

